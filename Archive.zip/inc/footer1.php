<footer class="site-footer">
				<div class="container">
					<img width="300px" src="../images/kritarth-white.png" alt="Kritarth 5.0">
					<address>
						<p>.<br><a href="tel:354543543"></a> <br> <a href="mailto:info@bandname.com">info.kritarth@gmail.com</a></p> 
					</address> 
					
					<!-- <form method="GET" action="register.php" class="newsletter-form" >
						<input type="email" name="reg_mail" placeholder="Enter your email to register now">
						<input type="submit" class="button cut-corner" value="Register">
					</form> -->
					<div class="social-links">
						<a target="_blank" href="https://www.facebook.com/pg/kritarth.kiit/about/?ref=page_internal"><i class="fa fa-facebook-square"></i></a>
						<a target="_blank" href="https://www.instagram.com/kritarth.kiit/?fbclid=IwAR2BuD89Or52v2wcHJBzGSLTfi7PUV9Z9RY69z9GGXNeQOifyb8mBtbkdwE"><i class="fa fa-instagram"></i></a>
						<a href="#"><i class="fa fa-google-plus"></i></a>
						<a href="#"><i class="fa fa-pinterest"></i></a>
					</div>
					<p class="copy">Copyright 2019 Kritarth 5.0 All right reserved</p>
				</div>
			</footer>
